myApp.controller("bookSearchController",function($scope,bookManage){
    
    $scope.bookSearchArr=bookManage.getAllbookDetails();
    $scope.deleteBookEventHandler=function(bookToBeDeleted)
    {
        bookManage.deleteBook(bookToBeDeleted);
        
    }
})
