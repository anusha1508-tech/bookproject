myApp.service("bookManage",function(){
    this.bookDetails=[
        { bookId: 101, bookName: "Believe in YourSelf", bookAuthor :"JOSEPH MURPHY", 
        descriptionofBook:"Believe in Yourself by Dr Murphy is a book that shows you how the power of believing in yourself can help you achieve success..",
        Price:"450",
        bookUrl:'Believe.jpg'
        },
        { bookId: 102, bookName: "Dont Polish Your Ignorance", bookAuthor :"Sadhguru", 
        descriptionofBook:"Dont Polish Your Ignorance",
        Price:"250",
        bookUrl:'Ignorance.jpg'
        },
        { bookId: 103, bookName: "Positive Thinking", bookAuthor :"Peale Norman Vincent", 
        descriptionofBook:" The Power of Positive Thinking.",
        Price:"150",
        bookUrl:'Positive.jpg'
        },
        { bookId: 104, bookName: "Think And Grow Rich", bookAuthor :"Napoleon Hill", 
        descriptionofBook:"Think and Grow Rich has earned itself The reputation of being considered a textbook for actionable techniques that can help one get better at doing anything.",
        Price:"100",
        bookUrl:'Thinkbook.jpg'
        }
       ];

    this.getAllbookDetails=function()
    {
        return this.bookDetails;
    }
    this.addBook=function(book)
    {
        this.bookDetails.push(book);
    }

    this.deleteBook=function(book){
        var pos=this.bookDetails.findIndex(item=> {
            if(item.bookId == book.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.bookDetails.splice(pos,1);
    }


})